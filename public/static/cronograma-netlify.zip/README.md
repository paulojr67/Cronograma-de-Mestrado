# 🌿 Cronograma Mestrado — S. cumini

Site estático **drop-ready** para o Netlify.

## 🚀 Como hospedar (30 segundos)

1. Acesse https://app.netlify.com/drop
2. Arraste **esta pasta inteira** (`dist-static`) para a área de drop
3. Pronto, no ar!

## 📁 Estrutura (mínima)

```
dist-static/
├── index.html              ← TUDO está aqui (HTML + CSS + JS + dados)
├── supabase-schema.sql     ← Script SQL para configurar o Supabase
├── netlify.toml            ← Config Netlify
├── _headers                ← Headers HTTP
└── README.md               ← Este arquivo
```

## ☁️ Sincronização Supabase (opcional)

Para sincronizar entre dispositivos:

1. Crie conta gratuita em https://supabase.com
2. Crie um novo projeto
3. No Dashboard → **SQL Editor** → cole o conteúdo de `supabase-schema.sql` → **RUN**
4. No site, clique no botão **"Supabase"** no topo
5. Cole `Project URL` e `anon public key` (Settings → API)
6. Salvar — pronto, multi-dispositivo!

## ✅ Sem Supabase?

Tudo funciona em modo local (localStorage do navegador). Use os botões **Exportar/Importar** para backup manual.

---

📅 Build: 2026-06-17
