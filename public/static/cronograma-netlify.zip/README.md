# Cronograma Mestrado — S. cumini

Site estático pronto para deploy no Netlify.

## Como hospedar

### Opção 1 (mais fácil): Drag & Drop
1. Acesse https://app.netlify.com/drop
2. Arraste **esta pasta inteira** (`dist-static`) para a área indicada
3. Pronto, no ar em segundos

### Opção 2: Deploy via Git
1. Push deste código para um repositório
2. Conecte o repo ao Netlify
3. Build command: (deixar vazio)
4. Publish directory: `.` (raiz)

## Estrutura
- `index.html` — página principal
- `static/` — CSS e JavaScript
- `api/` — endpoints JSON (estáticos)
- `netlify.toml` — configuração Netlify
- `_headers` — headers HTTP customizados
